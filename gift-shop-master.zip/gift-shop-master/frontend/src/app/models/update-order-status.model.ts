/**
 * @author Gagandeep Singh
 * @email singh.gagandeep3911@gmail.com
 * @create date 2021-01-26 11:36:46
 * @modify date 2021-01-26 11:36:46
 * @desc [description]
 */
export class UpdateOrderStatus {
  orderId: number;
  status: string;
}