/**
 * @author Gagandeep Singh
 * @email singh.gagandeep3911@gmail.com
 * @create date 2021-01-22 10:44:36
 * @modify date 2021-01-22 10:44:36
 * @desc [description]
 */
export enum Gender {
  Male = 'Male',
  Female = 'Female',
}
