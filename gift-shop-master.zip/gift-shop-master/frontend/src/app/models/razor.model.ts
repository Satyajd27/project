/**
 * @author Gagandeep Singh
 * @email singh.gagandeep3911@gmail.com
 * @create date 2021-01-28 11:59:47
 * @modify date 2021-01-28 11:59:47
 * @desc [description]
 */
export class RazorPay {
  razorpay_payment_id;
  razorpay_order_id;
  razorpay_signature;
}
