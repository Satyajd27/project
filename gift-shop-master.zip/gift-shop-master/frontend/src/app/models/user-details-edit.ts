/**
 * @author Gagandeep Singh
 * @email singh.gagandeep3911@gmail.com
 * @create date 2021-01-30 11:46:52
 * @modify date 2021-01-30 11:46:52
 * @desc [description]
 */
import { UserDetails } from './user-details.model';
export class UserDetailsEdit extends UserDetails {
  securityQuestion: string;
  securityAnswer: string;
}
