/**
 * @author Gagandeep Singh
 * @email singh.gagandeep3911@gmail.com
 * @create date 2021-02-05 19:00:47
 * @modify date 2021-02-05 19:00:47
 * @desc [description]
 */
export enum ProductStatus {
  ENABLED = 'Enabled',
  DISABLED = 'Disabled',
}
