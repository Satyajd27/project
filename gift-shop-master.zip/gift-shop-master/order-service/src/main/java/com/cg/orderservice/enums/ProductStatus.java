/**
 * @author Gagandeep Singh
 * @email singh.gagandeep3911@gmail.com
 * @create date 2021-01-13 17:58:40
 * @modify date 2021-01-13 17:58:40
 * @desc [description]
 */
package com.cg.orderservice.enums;

public enum ProductStatus {
  ENABLED, DISABLED;

}