package com.cg.orderservice.enums;

public enum PaymentType {

  COD, ONLINE

}
