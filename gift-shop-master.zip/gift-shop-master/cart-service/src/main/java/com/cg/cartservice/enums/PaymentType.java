package com.cg.cartservice.enums;

public enum PaymentType {

  COD, ONLINE

}
