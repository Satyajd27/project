package com.cg.databaseserver.enums;

public enum PaymentType {

  COD, ONLINE

}
