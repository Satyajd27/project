/**
 * @author Gagandeep Singh
 * @email singh.gagandeep3911@gmail.com
 * @create date 2021-01-14 11:44:43
 * @modify date 2021-01-14 11:44:43
 * @desc [description]
 */
package com.cg.authservice.enums;

public enum PaymentType {

  COD, ONLINE

}
